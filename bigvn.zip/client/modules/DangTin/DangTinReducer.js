// Import Actions
import { ACTIONS } from './DangTinActions';

// Initial State
const initialState = {
};

const DangTinReducer = (state = initialState, action) => {
  switch (action.type) {
    default:
      return state;
  }
};


// Export Reducer
export default DangTinReducer;
